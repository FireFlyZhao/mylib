Open Source Licenses
====================

The individual JUnit modules/artifacts use different open source licenses:

- `junit-platform-surefire-provider` uses [Apache License v2.0](junit-platform-surefire-provider/LICENSE.md)
- All other modules use [Eclipse Public License v2.0](junit-jupiter-api/LICENSE.md).

Please see the `LICENSE.md` files in the subfolders for details.
